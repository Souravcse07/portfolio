const typed = new Typed("#typed", {
  strings: ["Sourav", "Full Stack Developer"],
  typeSpeed: 100,
  backSpeed: 50,
  backDelay: 1500,
  loop: true,
});
